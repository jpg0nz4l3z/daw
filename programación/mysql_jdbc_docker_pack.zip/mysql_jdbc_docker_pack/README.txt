PAQUETE DOCKER: MySQL para prácticas JDBC (DAW 1º)

1) Qué incluye
- docker-compose.yml
  - Levanta MySQL 8.0 en un contenedor y publica el puerto 3306 SOLO en 127.0.0.1.
  - Incluye Adminer (opcional) en http://127.0.0.1:8080.
- init/00_full_privileges.sql
  - Concede privilegios globales al usuario de prácticas (tuusario / tucontraseña),
    de modo que pueda crear tantas bases de datos como quiera y operar plenamente en ellas.

2) Requisitos en el equipo
- Docker Desktop (Windows/Mac) o Docker Engine (Linux)
- Docker Compose v2 (normalmente integrado: "docker compose version")

3) Arranque
Desde esta carpeta (la que contiene docker-compose.yml):
  docker compose up -d

Comprobar estado:
  docker compose ps

Si el servicio "mysql" está "healthy", ya admite conexiones.

4) Credenciales y conexión
Usuario: tusuario
Password: tucontraseña
Host: 127.0.0.1
Puerto: 3306

URL JDBC (sin base de datos, para poder hacer CREATE DATABASE):
  jdbc:mysql://127.0.0.1:3306/?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=Europe/Madrid

Después, para trabajar en una base concreta:
  jdbc:mysql://127.0.0.1:3306/NOMBRE_BD?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=Europe/Madrid

5) Verificación con Adminer (opcional)
Abrir en el navegador:
  http://127.0.0.1:8080

Datos:
- Sistema: MySQL
- Servidor: mysql
- Usuario: tuusario
- Contraseña: tucontraseña

6) Reset (MUY IMPORTANTE)
Los scripts de init/ SOLO se ejecutan la primera vez (cuando el volumen está vacío).
Para dejar todo limpio y volver al estado inicial:
  docker compose down -v
  docker compose up -d

7) Notas de seguridad / control
- El puerto 3306 está publicado SOLO en localhost (127.0.0.1), no en la red.
- El usuario "tuusario" tiene privilegios globales dentro del contenedor (intencional para prácticas).
  Si un alumno "rompe" algo, se soluciona con el reset del punto 6.

8) Errores típicos
- "Communications link failure": el contenedor no está arrancado o el puerto 3306 no está publicado.
  Revisa "docker compose ps".
- "Access denied": usuario/clave incorrectos.
- Si has cambiado algo y "no surte efecto", probablemente no has reseteado el volumen (punto 6).
