-- 00_full_privileges.sql
-- Objetivo: que el usuario "tuusario" (el del compose) pueda:
--   - Crear/borrar bases de datos
--   - Crear/alterar/borrar tablas
--   - Insertar/modificar/borrar datos
--   - En general, operar con control total sobre cualquier esquema que cree
--
-- Nota: esto es intencionalmente "sin restricciones" dentro del contenedor.
-- En un contenedor por puesto, el control se hace por aislamiento + reset del volumen.

CREATE USER IF NOT EXISTS 'tusuario'@'%' IDENTIFIED BY 'tucontraseña';

-- Privilegios globales. Permite trabajar en todas las BBDD, incluidas las creadas desde JDBC.
GRANT ALL PRIVILEGES ON *.* TO 'tuusario'@'%';



FLUSH PRIVILEGES;
