
package POO.POO.Bloque1;
public class Cuenta {
    long num, saldo;
    public void mostrar_saldo(){
       System.out.println("El saldo es: " + saldo);
    }
    public void recibir_abonos(long ing){
     saldo+=ing;
    }
    public void pagar_recibos(long rec){
    saldo -= rec;
    }
}

