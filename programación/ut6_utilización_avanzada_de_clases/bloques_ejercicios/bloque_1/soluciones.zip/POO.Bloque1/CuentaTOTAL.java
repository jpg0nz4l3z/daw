/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package POO.POO.Bloque1;

public class CuentaTOTAL{
//Ejercicio 8.
public static class Cuenta {
    String titular;
    double cantidad;
    public void Cuenta(){}
    public void setTitular(String tit){this.titular = tit;}
    public String getTitular(){return titular;}
    public void setCantidad(double din){this.cantidad=din;}
    public double getCantidad(){return cantidad;}
    
    public void mostrar(){
       System.out.println("Titular: "+getTitular());
       System.out.println("Dinero en cuenta: " + getCantidad() + "€");
    }
    public void ingresar(double dinero){
        double nueva_cantidad = getCantidad() + dinero;
        if (dinero >=0) setCantidad(nueva_cantidad);
    }
    public void retirar(double dinero){
       double nueva_cantidad = getCantidad() - dinero;
       setCantidad(nueva_cantidad);
    }

    }

//9 Cuenta Joven
static class CuentaJoven extends Cuenta{
   double bonificacion;
   int edad;

   public CuentaJoven(int edad){this.edad=edad;}
   
   private CuentaJoven() {}
   
   public void setBonificacion(double bonif){this.bonificacion=bonif;};
   public double getBonificacion(){return bonificacion;}
  
   public boolean titularValido(){
       boolean positivo;
       if(edad>=18 && edad<25)positivo=true;
       else positivo=false;
       return positivo;
   }
   
   public void retirar(double cantidad){
      if (titularValido()){
         super.retirar(cantidad);
      }
   }
   
   public void mostrar(){
      super.mostrar();
      if (titularValido()){
         System.out.println("CUENTA JOVEN");
         System.out.println("Bonificacion: " + getBonificacion() + "%");
      }
      else System.out.println("No puede tener una CuentaJoven debido a su edad " + edad);
   }
}

public static void main (String[] args){
    
   Cuenta cliente = new Cuenta();
   cliente.setTitular("TitularCuenta1");
   cliente.setCantidad(2000);
   cliente.mostrar();
   double dineroRetirar = 2000;
   System.out.println("Ahora el cliente " + cliente.getTitular() + " va a retirar " + dineroRetirar + "€");
   cliente.retirar(dineroRetirar);
   cliente.mostrar();
   double dineroIngresar = 5500.25;
   System.out.println("Ahora el cliente " + cliente.getTitular() + " va a ingresar " + dineroIngresar + "€");
   cliente.ingresar(dineroIngresar);
   cliente.mostrar();
   
   System.out.println("");
   
   CuentaJoven cliente1 = new CuentaJoven(24);
   cliente1.setTitular("TitularCuentaJoven1");
   cliente1.setBonificacion(30);
   cliente1.setCantidad(18000);
   cliente1.mostrar();
   cliente1.retirar(20000);
   cliente1.mostrar();
   
   System.out.println("");
      
   Cuenta cliente2 = new CuentaJoven(30);
   cliente2.setTitular("TitularCuentaJoven2");
   ((CuentaJoven)cliente2).setBonificacion(30);
   cliente2.setCantidad(12000);
   cliente2.mostrar();
   cliente2.retirar(20000);
   cliente2.mostrar();

   
}
}