
package POO.POO.Bloque1;
//ejercicio 15.
public class Libro {
    String ISBN,Titulo,Autor;
    int numpag;
    public void setISBN(String is){this.ISBN=is;}
    public String getISBN(){return ISBN;}
    public void setTItulo(String ti){this.Titulo=ti;}
    public String getTitulo(){return Titulo;}
    public void setAutor(String au){this.Autor=au;}
    public String getAutor(){return Autor;}
    public void setNumpag(int num){this.numpag=num;}
    public int getNumpag(){return numpag;}
    public void LibrotoString(){
       System.out.println("El libro con ISBN " + getISBN()+ ", creado por el autor "+ getAutor() +" tiene " + getNumpag() +" páginas");
    }
public static void main (String [] args){
   Libro libro1 = new Libro();
   Libro libro2 = new Libro();
   libro1.setAutor("Jorge F Durán");
   libro1.setISBN("B12345");
   libro1.setNumpag(456);
   libro1.setTItulo("Lo que ha de venir.");
   libro2.setAutor("Jorge F Durán");
   libro2.setISBN("B12231");
   libro2.setNumpag(927);
   libro2.setTItulo("Que venga.");
   libro1.LibrotoString();
   libro2.LibrotoString();
   
   if(libro1.getNumpag()>libro2.getNumpag())
       System.out.println("El libro " + libro1.getTitulo() + " tiene más páginas que el libro " + libro2.getTitulo());
   else if(libro2.getNumpag()>libro1.getNumpag())
       System.out.println("El libro " + libro2.getTitulo() + " tiene más páginas que el libro " + libro1.getTitulo());
   else 
       System.out.println("Los dos libros tienen las mismas páginas.");
   }
}
