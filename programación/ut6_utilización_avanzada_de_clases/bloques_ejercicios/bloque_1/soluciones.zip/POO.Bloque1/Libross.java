package POO.POO.Bloque1;

public class Libross{
	String titulo, autor;
	int numPag, calificacion;
	public Libross(){}
	public Libross(String titulo, String autor, int numpag, int calif){
		this.titulo=titulo;
	    this.autor = autor;
	    this.numPag=numpag;
	    this.calificacion=calif;
	}
}
class ConjuntoLibros{
	public void almacenarlibros(Libross [] conjunto){
		for (int i = 0; i < conjunto.length-3; i++)
	        conjunto[i] = new Libross("Titulo"+i, "Autor"+i, (int)(Math.random()*300+200), (int)(Math.random()*10));
	}
	public void añadirlibro(Libross libro, Libross [] conjunto){
	    for(int i =0; i<conjunto.length; i++){
			if(conjunto[i] ==null){
		        conjunto[i]=libro;
		        break;
			}
	    }
	}
    public void eliminarlibro(String palabra, String tipo, Libross [] conjunto){
        for(int i = 0; i<conjunto.length; i++){
	        if(conjunto[i]!=null){
	            if(tipo.equals("autor"))
		            if(conjunto[i].autor.equals(palabra))
		                conjunto[i]=null;
				if(tipo.equals("titulo"))
		            if(conjunto[i].titulo.equals(palabra))
		                conjunto[i]=null;
	        }
	    }
	    System.out.println("El libro cuyo " + tipo + " es \"" + palabra + "\" ha sido eliminado.");
	}
    public void calificacionmaxymin(Libross [] conjunto){
	    Libross max = new Libross();
		max.calificacion = 0;
	    Libross min = new Libross();
	    min.calificacion = 11;
		for(int i = 0; i < conjunto.length;i++){
	        if(conjunto[i]!=null){
	            if(conjunto[i].calificacion > max.calificacion) max=conjunto[i];
	            if(conjunto[i].calificacion < min.calificacion) min=conjunto[i];
	        }
	    }
	    System.out.println("El libro \"" + max.titulo + "\" tiene la máxima calificación con " + max.calificacion + " puntos");
	    System.out.println("El libro \"" + min.titulo + "\" tiene la mínima calificación con " + min.calificacion + " puntos");
	}
    public void todosLosLibros(Libross [] conjunto){
		for(int i=0; i<conjunto.length;i++){
	        if(conjunto[i] != null){
	            System.out.println("Titulo: " + conjunto[i].titulo);
	            System.out.println("Autor: " + conjunto[i].autor);
	            System.out.println("Número Páginas: " + conjunto[i].numPag);
	            System.out.println("Calificación: " + conjunto[i].calificacion);
	            System.out.println("---------------------------------------------");
	        }
	    }
	}
}

