/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package POO.POO.Bloque1;

public class Persona {
   String nombre,DNI;
   Cuenta[] cuentas = new Cuenta[3];
   public void setnombre(String nomb) {nombre=nomb;}
   public String getnombre(){return nombre;}
   public void setDNI(String dni){DNI=dni;}
   public String getDNI(){return DNI;}
   public void añadir_cuentas(Cuenta cuent){
      for(int i=0; i<3; i++){
          if(cuentas[i]==null){
             cuentas[i]=cuent;
             break;
          }
      }
   }
   public void moroso(){
      boolean moroso=false;
      for(int i=0; i<3; i++)
         if(cuentas[i]!=null && cuentas[i].saldo<0)
             moroso=true;        
      if(moroso)System.out.println(getnombre() + " es moroso");
      else System.out.println(getnombre() + " no es moroso");
   } 
   
   public void transferencia(Cuenta c1, Cuenta c2, int cantidad){
      c1.pagar_recibos(cantidad);
      c2.recibir_abonos(cantidad);
   }
}
