

package POO.POO.Bloque1;

public class PruebaCuentas {
    public static void main (String[] args){

       Persona per = new Persona();
       per.setDNI("11122211A");
       per.setnombre("Jorge");

       Cuenta cuen = new Cuenta();
       cuen.num=1112233;
       cuen.saldo=0;
       per.añadir_cuentas(cuen);

       Cuenta cuen1 = new Cuenta();
       cuen1.num=222111222;
       cuen1.saldo=700;
       per.añadir_cuentas(cuen1);

       cuen.recibir_abonos(1100);
       cuen1.pagar_recibos(750);

       System.out.println(cuen.saldo + "\n" + cuen1.saldo);
       per.moroso();

       per.transferencia(per.cuentas[0],per.cuentas[1],700);
       cuen.mostrar_saldo();
       cuen1.mostrar_saldo();

    }
}
