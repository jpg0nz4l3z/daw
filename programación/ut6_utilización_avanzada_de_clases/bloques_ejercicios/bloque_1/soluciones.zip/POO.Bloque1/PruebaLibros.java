package POO.POO.Bloque1;

public class PruebaLibros {
    public static void main(String[]args){
       ConjuntoLibros libros = new ConjuntoLibros();
       Libross[] conjunto = new Libross[8];
       
       libros.almacenarlibros(conjunto);
 
	   String autor = "El Autor Peregrino";
	   int numPag=450;
	   String titulo="Los Títulos Los Carga el Diablo";
	   int calificacion=4;
	   Libross lib = new Libross(titulo,autor,numPag,calificacion);
	   libros.añadirlibro(lib, conjunto);
     
	   autor = "Mauricio Mercio";
	   numPag=350;
	   titulo="En La Noche Más Oscura";
	   calificacion=8;
	   Libross lib1 = new Libross(titulo,autor,numPag,calificacion);
	   libros.añadirlibro(lib1, conjunto);

	   autor = "Mercader Cuadrado";
	   numPag=550;
	   titulo="Se Me Fundieron Los Plomos";
	   calificacion=7;
	   Libross lib2 = new Libross(titulo,autor,numPag,calificacion);
	   libros.añadirlibro(lib2, conjunto);

	   autor = "Abinio Monsenior";
	   numPag=335;
	   titulo="Me Tropecé Con La Cruda Realidad";
	   calificacion=8;
	   Libross lib3 = new Libross(titulo,autor,numPag,calificacion);
	   libros.añadirlibro(lib3, conjunto);
	         
	   autor = "Gerardo Molano";
	   numPag=345;
	   titulo="Que Venía De Paso";
	   calificacion=6;
	   Libross lib4 = new Libross(titulo,autor,numPag,calificacion);
	   libros.añadirlibro(lib4, conjunto);
	   System.out.println();

	   libros.eliminarlibro("Mercader Cuadrado", "autor", conjunto);
	   libros.eliminarlibro("Los Titulos Los Carga el Diablo", "titulo", conjunto);
	   System.out.println();

	   libros.calificacionmaxymin(conjunto);
	   System.out.println();

	   libros.todosLosLibros(conjunto);
    }
}
