/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package POO.POO.Bloque1;

import POO.Rectangulo;

/**
 *
 * @author Jorge Florentino
 */
public class PruebaRectangulo {
    public static void main(String[]args){
    POO.Rectangulo rect = new Rectangulo(2,3);
    System.out.println("area :" + rect.area());
    System.out.println("perímetro " + rect.perimetro());
    }
}
