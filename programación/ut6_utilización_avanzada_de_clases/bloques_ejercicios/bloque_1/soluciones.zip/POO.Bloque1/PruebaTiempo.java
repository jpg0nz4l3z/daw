/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package POO.POO.Bloque1;

import POO.Tiempo;

/**
 *
 * @author Jorge Florentino
 */
public class PruebaTiempo {
    public static void main (String [] args){
    Tiempo tiemp = new Tiempo(12,30,45);

    tiemp.horacompleta(23, 59, 00);
    System.out.println("La hora modificada es: " + tiemp.hora + ":"+  tiemp.minutos  + ":" + tiemp.segundos);
    System.out.println();
    POO.Tiempo tiemphm = new POO.Tiempo(12,30);
    tiemphm.horaminutos(23, 59);
    System.out.println("La hora modificada es: " + tiemphm.hora + ":"+  tiemphm.minutos);

    System.out.println();
    POO.Tiempo tiemph = new Tiempo(12);
    tiemph.hora(23);
    System.out.println("La hora modificada es: " + tiemph.hora);

    }
}
