/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package POO.POO.Bloque1;

/**
 *
 * @author Jorge Florentino
 */
public class Rectangulo {
    int base;
    int altura;
    public Rectangulo(int are, int alt){
       this.base=are;
       this.altura=alt;
    }
    public int area(){
      return base*altura;
    } 
    public int perimetro(){
       return 2*base+2*altura;
    }
}
