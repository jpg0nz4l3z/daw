
package POO.POO.Bloque1;

/*
Crea una clase Rectangulo que modele rectángulos por medio de cuatro puntos (los
vértices). Dispondrá de dos constructores: uno que cree un rectángulo partiendo de sus
cuatro vértices y otro que cree un rectángulo partiendo de la base y la altura, de forma
que su vértice inferior izquierdo esté en (0,0). La clase también incluirá un método para
calcular la superficie y otro que desplace el rectángulo en el plano.
*/
public class Rectangulo2 {
    int[][] puntos = new int[4][2];  
    int base, altura;
   public Rectangulo2(int[] punt1, int[] punt2, int[] punt3, int[] punt4){
      this.puntos[0] = punt1;
      this.puntos[1] = punt2;
      this.puntos[2] = punt3;
      this.puntos[3] = punt4;
   }    
   public Rectangulo2(int base, int altura){
       this.puntos[0][0] = 0; //x del primero
       this.puntos[0][1] = 0; //y del primero
       this.puntos[1][0] = this.puntos[0][0]+base; //x del segundo
       this.puntos[1][1] = this.puntos[0][1];//y del segundo
       this.puntos[2][0] = this.puntos[0][0]+base; //x del tercero
       this.puntos[2][1] = this.puntos[0][1]+altura; //y del tercero
       this.puntos[3][0] = this.puntos[0][0]; //x del cuarto
       this.puntos[3][1] = this.puntos[0][1]+altura; // y del cuarto
   }
   public int superficie(){
      int base = (int) this.puntos[1][0] - (int) this.puntos[0][0];
      int altura = (int) this.puntos[3][1] - (int) this.puntos[0][1];
      return base*altura;
   } 
  public void desplazamiento(int x, int y){
     for (int i=0;i<puntos.length;i++){
	 puntos[i][0] += x;
	 puntos[i][1] += y;
	}
     }
  public String puntosString(){
      String puntosxy = "(";
      for(int i=0;i<puntos.length;i++){
         for(int j = 0; j<puntos[0].length;j++){
	    if (j==0) puntosxy = puntosxy + puntos[i][j] ;
	    else puntosxy = puntosxy + ", " + puntos[i][j] ;
	 }
	    if (i!= puntos.length-1)puntosxy = puntosxy + "), (";
	    else puntosxy = puntosxy + ")";
      }
     return "puntos del rectángulo: ["+  puntosxy + "]";
  }
  public static void main(String [] args){
      int [] v1 = {0,0};
      int [] v2 = {4,0};
      int [] v3 = {4,3};
      int [] v4 = {0,3};     
      Rectangulo2 rect = new Rectangulo2(v1,v2,v3,v4);
      System.out.println(rect.puntosString());
      System.out.println("Superficie: "+rect.superficie());
      int x = 2, y = 3;
      System.out.println("Desplazar el rectángulo: x= " + x + ", y= " + y);
      rect.desplazamiento(x, y);
      System.out.println(rect.puntosString());
      
      System.out.println("");
      
      Rectangulo2 rect1 = new Rectangulo2(20,30);
      int pun1 = rect1.puntos[0][0];
      System.out.println(pun1);
      System.out.println(rect1.puntosString());
      System.out.println("Superficie: "+rect1.superficie());
      x = 20;
      y = 30;
      System.out.println("Desplazar el rectángulo: x= " + x + ", y= " + y);
      rect1.desplazamiento(x, y);
      System.out.println(rect1.puntosString());
      
  }
}
