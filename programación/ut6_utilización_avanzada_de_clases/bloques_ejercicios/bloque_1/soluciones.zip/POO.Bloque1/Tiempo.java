/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package POO.POO.Bloque1;

public class Tiempo {
    int hora, minutos, segundos;
    public Tiempo(int ho, int min, int seg){
      this.hora = ho;
      this.minutos = min;
      this.segundos = seg;
      System.out.println("La hora completa es: " + ho + ":" + min + ":" + seg);
    }
    public Tiempo(int ho, int min){
      this.hora = ho;
      this.minutos = min;
      System.out.println("La hora con minutos es : " + ho + ":" + min);
    }
    public Tiempo(int ho){
      this.hora = ho;    
      System.out.println("La hora es: " + ho);
    }
    
    public void horacompleta(int hora, int minutos, int segundos){
      horaminutos(hora,minutos);
      if(segundos>=0 && segundos<60)
	  this.segundos=segundos;
      else System.out.println("Los segundos no son correctos, no se modificarán");
    }

   public void horaminutos(int hora, int minutos){
      hora(hora);
      if(minutos>=0 && minutos<60) this.minutos=minutos;
      else System.out.println("Los minutos no son correctos, no se modificarán");
    }

   public void hora(int hora){
      if(hora>=0 && hora <24) this.hora=hora;
      else System.out.println("La hora no es correcta, no se modificará");
    }

}
