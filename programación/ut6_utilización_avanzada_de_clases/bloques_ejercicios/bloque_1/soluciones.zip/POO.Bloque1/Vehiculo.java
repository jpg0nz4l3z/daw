/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package POO.POO.Bloque1;

import java.util.Scanner;

//ejercicio 4 POO.
public class Vehiculo {   
       String nombre;
       int num_pasajeros;
       boolean con_tripulacion;
       int num_ruedas;
       String fch_matriculacion;
       String medio;

    public Vehiculo(String nomb, int nump, boolean contrip, int numrued, String fmatri, String medio) {
	  this.nombre=nomb;
	  this.con_tripulacion=contrip;
	  this.fch_matriculacion=fmatri;
	  this.num_pasajeros=nump;
	  this.num_ruedas=numrued;
	  this.medio = medio;
    }
    public Vehiculo(){}
    
    
    public static Vehiculo cargar_vehiculo(Scanner sc, Vehiculo vehiculo){  
       String nombre="";
       int num_pasajeros=0;
       boolean con_tripulacion=false;
       int num_ruedas=0;
       String fch_matriculacion="";
       String medio="";
       System.out.print("Nombre: ");
       nombre=sc.nextLine();
       System.out.print("Num_pasajeros: ");
       num_pasajeros=sc.nextInt();
       System.out.print("Con tripulacion: ");
       con_tripulacion = sc.nextBoolean();
       System.out.print("Num_ruedas: ");
       num_ruedas= sc.nextInt();
       System.out.print("Fech. Matriculacion: ");
       sc.nextLine();	   
       fch_matriculacion = sc.nextLine();
       System.out.print("Medio: ");
       medio = sc.nextLine();
       vehiculo = new Vehiculo(nombre, num_pasajeros, con_tripulacion, num_ruedas, fch_matriculacion, medio);
       return vehiculo;
    }
    
    public static void mostrar_vehiculo(Scanner sc, Vehiculo vehiculo){
        System.out.println("Dame el vehículo que quieres consultar");
	String nombreveh = sc.nextLine();
	//for (int i = 0; i < vehiculo.length;i++){
	    System.out.println();
	   //if(vehiculo.nombre.equals(nombreveh)){
	      System.out.println("Nombre: " + vehiculo.nombre);
	      System.out.println("Num_pasajeros: " + vehiculo.num_pasajeros);
	      System.out.println("Con tripulacion: " + vehiculo.con_tripulacion);
	      System.out.println("Num_ruedas: " + vehiculo.num_ruedas);
	      System.out.println("Fech. Matriculacion: " + vehiculo.fch_matriculacion);
	      System.out.println("Medio: " + vehiculo.medio);
	   
	   //}
	//}
    }
    
    
    public static void main(String[]args){
       System.out.println("Introduce dos vehículos: nombre, num_pasajeros, con_tripulacion, num_ruedas, fecha_matri, medio");
       Scanner sc = new Scanner(System.in);
       Vehiculo coche = new Vehiculo();
       Vehiculo moto = new Vehiculo();
       
       coche = cargar_vehiculo(sc,coche);
       mostrar_vehiculo(sc,coche);
       
       moto = cargar_vehiculo(sc,moto);
       mostrar_vehiculo(sc,moto);
       
   }
}
