
package POO.Bloque2;

public class Inmuebles {
    String direccion;
    int superficie, anios, preciobase;
    public void setDireccion(String direccion) {
	this.direccion = direccion;
    }
    public void setAnios(int anios) {
	this.anios = anios;
    }
    public void setPreciobase(int preciobase) {
	this.preciobase = preciobase;
    }
    public String getDireccion() {
	return direccion;
    }
    public int getAnios() {
	return anios;
    }
    public int getPreciobase() {
	return preciobase;
    }
    public int getprecio(){
        int precio;
        if(this.anios<15)
            precio=(int)(Math.round(0.99*preciobase));
        else
            precio = (int)(Math.round(0.98*preciobase));
        return precio;
    }
}

class Pisos extends Inmuebles{
    int piso;
    public int getPiso() {
	return piso;
    }
    public void setPiso(int piso) {
	this.piso = piso;
    }
   @Override
    public String getDireccion() {
	return direccion;
    }
   @Override
    public int getPreciobase() {
	return preciobase;
    }
   @Override
    public void setDireccion(String direccion) {
	this.direccion = direccion;
    }
   @Override
    public void setPreciobase(int preciobase) {
	this.preciobase = preciobase;
    }
   @Override
   public int getprecio(){
      int precio = super.getprecio();
      if(piso>=3){precio=(int)(Math.round(1.03*precio));}
      return precio;
   }
}

class Locales extends Inmuebles{
   int num_ventanas;
    public int getNum_ventanas() {
	return num_ventanas;
    }
    public void setNum_ventanas(int num_ventanas) {
	this.num_ventanas = num_ventanas;
    }
   @Override
    public String getDireccion() {
	return direccion;
    }
    public int getSuperficie() {
	return superficie;
    }
   @Override
    public void setDireccion(String direccion) {
	this.direccion = direccion;
    }
    public void setSuperficie(int superficie) {
	this.superficie = superficie;
    }
   @Override
   public int getprecio(){
      int precio = super.getprecio();
      if(superficie>50) precio=(int)(1.01*precio);
      if(num_ventanas<=1) precio = (int) (precio - Math.round(0.02*super.getprecio()));
      if(num_ventanas >4) precio = (int) (precio + Math.round(0.02*super.getprecio()));
      return precio;
   }
}