/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package POO.Bloque2;

/**
 *
 * @author Jorge Florentino
 */
public class PersonalUniversidad {
    String nombre, apellido1, apellido2, DNI, estado_civil;
    PersonalUniversidad(){};
    PersonalUniversidad(String nom, String ap1, String ap2, String dni, String sc){
        this.nombre=nom;
        this.apellido1=ap1;
        this.apellido2=ap2;
        this.DNI=dni;
        this.estado_civil=sc;
    }
	  
    static class estudiantes extends PersonalUniversidad{
        int curso;
        public estudiantes(int curs){
       this.curso = curs;
    }
   }

   static class profesores extends PersonalUniversidad{
       String departamento;
       public profesores(String department, String nom,String ap1,String ap2,String dni,String sc){
	       super(nom,ap1,ap2,dni,sc);
	       this.departamento = department;
       }
   }

   static class servicio extends PersonalUniversidad{
       String seccion;
       public servicio(String sec, String nom, String ap1, String ap2, String dni, String sc){
	       super(nom,ap1,ap2,dni,sc);
           this.seccion=sec;
       }
   }

   public static void main(String [] args){
      estudiantes est = new estudiantes(1);
      est.curso=1;
      est.nombre="Ana";
      est.apellido1="Gomez";
      est.apellido2="Gomez";
      est.DNI="1212123A";
      est.estado_civil="c";
      System.out.println("Curso: " + est.curso+",\n nombre: "+est.nombre+",\n apellidos: "+est.apellido1 + " " + est.apellido2+",\n DNI: "+est.DNI+",\n Estado civil; "+est.estado_civil);
      System.out.println("");
      estudiantes est1 = new estudiantes(1);
      est.curso=2;
      est1.nombre="Sara";
      est1.apellido1="Gonzalez";
      est1.apellido2="García";
      est1.DNI="13332123A";
      est1.estado_civil="s";
      System.out.println("Curso: " + est.curso+",\n nombre: "+est1.nombre+",\n apellidos: "+est1.apellido1 + " " + est1.apellido2+",\n DNI: "+est1.DNI+",\n Estado civil; "+est1.estado_civil);
      
      
    }
}
