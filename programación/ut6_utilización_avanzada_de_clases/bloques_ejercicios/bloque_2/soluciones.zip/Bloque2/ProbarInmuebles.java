
package POO.Bloque2;

public class ProbarInmuebles {
    public static void main(String [] args){
    Inmuebles inm1 = new Inmuebles();
    inm1.setDireccion("C/San Anton, 125, 1ºC");
    inm1.setAnios(15);
    inm1.setPreciobase(74000);
    System.out.println("El inmueble sito en " + inm1.getDireccion() + " con una antiguedad de " + inm1.getAnios() + " años tiene un precio de " + inm1.getprecio() + "€");
    
    Pisos piso1 = new Pisos();
    piso1.setDireccion("C/Ventas, 134 5ºC");
    piso1.setAnios(34);
    piso1.setPreciobase(67000);
    piso1.setPiso(5);
    System.out.println("El inmueble sito en " + piso1.getDireccion() + " con una antiguedad de " + piso1.getAnios() + " años tiene un precio de " + piso1.getprecio() + "€");

    Pisos piso2 = new Pisos();
    piso2 = (Pisos) inm1;
    piso2.setPiso(3);
    System.out.println("El piso "+ piso2.getPiso() + " sito en " + piso2.getDireccion() + " con una antiguedad de " + piso2.getAnios() + " años tiene un precio de " + piso2.getprecio() + "€");

    
    Locales local1 = new Locales();
    local1.setDireccion("Av/ Castellana, 345 7ºC");
    local1.setAnios(20);
    local1.setPreciobase(87500);
    local1.setNum_ventanas(4);
    System.out.println("El inmueble sito en " + local1.getDireccion() + " con una antiguedad de " + local1.getAnios() + " años tiene un precio de " + local1.getprecio() + "€");

}}
