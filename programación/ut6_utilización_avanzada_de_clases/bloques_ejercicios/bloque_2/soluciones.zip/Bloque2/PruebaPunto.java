
package POO.Bloque2;

public class PruebaPunto {
    public static void main(String[] args){
       Punto punto = new Punto();
       punto.setX(3);
       punto.setY(3);
       System.out.println(punto.toString());
       Circulo circulo = new Circulo();
       circulo.setRadio(4);
       circulo.setX(2);
       circulo.setY(6);
       System.out.println(circulo.toString());
    }
}
