/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package POO.Bloque2;

/**
 *
 * @author Jorge Florentino
 */
public class Punto {
    int x;
    int y;
    public Punto(){
       this.x=0;
       this.y=0;
    }
    public void setX(int x) {this.x = x;}
    public void setY(int y) {this.y = y;}
    public int getX() {return x;}
    public int getY() {return y;}

    @Override
    public String toString() {
	char cuad=0;
	if(x>0){
	   if(y>0)  cuad= '1';
	   else if(y<0){ cuad='3';}
	}else if(x<0){
	   if(y>0) cuad = '2';
	   else if(y<0) cuad = '4';
	}
	return "Punto{" + "x=" + x + ", y=" + y + "}, Cuadrante(" + cuad + ")";
    }
}

class Circulo extends Punto{
int radio;
public Circulo(){
  super.x=0;
  super.y=0;
  radio=20;
  
}
 public int getRadio() { return radio; }
 public void setRadio(int radio) { this.radio = radio;}

    @Override
    public String toString() {
	boolean [] cuad = {false,false,false,false};
	double x1,y1;
	for(int i=0; i<360; i++){
	   x1= x + radio*Math.cos(i);
	   y1  = y + radio*Math.sin(i);
	   if(x1>0){
	      if(y1>0)  cuad[0]= true;
	      else if(y1<0){ cuad[2]=true;}
	   }else if(x1<0){
	      if(y1>0) cuad[1] = true;
	      else if(y1<0) cuad[3] = true;
	   }
        }
	return "Circulo{(" + super.x +", "+ super.y +"), radio=" + radio + ", cuadrantes: [ 1: " + cuad[0] + ", 2: " + cuad[1] +", 3: " + cuad[2]+", 4:" + cuad[3]+   '}';
    }
    
}
