/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package POO.Bloque3.Centralita;

public abstract class Centralita {
    int num_llamadas;
    double coste_total;
    public Centralita(){}
    public Centralita(int llamadas, float coste_total){
      this.num_llamadas = llamadas;
      this.coste_total = coste_total;
    }
    public int num_llamadas(int num_llamadas){
	   num_llamadas += 1;
       return num_llamadas;
    }
    public abstract double coste();
    public double coste_total(double coste_total, double coste){
       coste_total += coste;
       return coste_total;
    }
}    

    class llamadas extends Centralita{
       String tipo;
       int franja;
       double num_or, num_dest, duracion;
       
       public llamadas(String tipo, int franja, double numor, double numdest, double dur){
       super();
       this.tipo = tipo;
       this.franja=franja;
       this.num_or=numor;
       this.num_dest = numdest;
       this.duracion = dur;
       }
       
     @Override
     public double coste(){
	 double coste = 0;
	 if(tipo.equals("local"))
	     coste = 5*duracion;
	 if(tipo.equals("provincial")){
	    if(franja==1) coste = 8*duracion;
	    if(franja==2) coste = 12*duracion;
	    if(franja==3) coste = 16*duracion;
	 }
        return coste;
     } 
     
     public void datos(){
        System.out.println("Num_origen: " + num_or + ", Num_destino: " + num_dest + ", Duracion: " + duracion);
     }
     
 }
