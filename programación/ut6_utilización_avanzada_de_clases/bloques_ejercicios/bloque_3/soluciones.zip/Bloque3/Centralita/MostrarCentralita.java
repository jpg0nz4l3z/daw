/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package POO.Bloque3.Centralita;

public class MostrarCentralita {
    public static void main(String[]args){
    double costetotal = 0;

    llamadas llamada1 = new llamadas("provincial",1,121212,23232323,23);
    System.out.println("Coste de la llamada: " + llamada1.coste());
    costetotal = llamada1.coste_total(costetotal,llamada1.coste());
    llamada1.datos();
    System.out.println("Coste total de llamadas: " + costetotal);
    int numllamadas = llamada1.num_llamadas(llamada1.num_llamadas);
    System.out.println("Número de llamadas: " + numllamadas);
    
    llamadas llamada2 = new llamadas("local",3,22121212,99232323,123);
    System.out.println("Coste de la llamada: " + llamada2.coste());
    costetotal = llamada2.coste_total(costetotal, llamada2.coste());
    llamada2.datos();
    System.out.println("Coste total de llamadas: " + costetotal);
    numllamadas = llamada2.num_llamadas(numllamadas);
    System.out.println("Número de llamadas: " + numllamadas);
}}
