/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package POO.Bloque3.Figura;

/**
 *
 * @author Jorge Florentino
 */
public abstract class Figura {
    String nombre;
    public void setNombre(String nom){
       this.nombre=nom;
    }
    public String getNombre(){
       return this.nombre;
    }
    public abstract double getArea();
    public abstract double getVolumen();
    public boolean equals(Object obj){
        System.out.println(this + " =¿? " + obj);
        if (this!=obj || obj == null || this.getClass() != obj.getClass()) return false;
        else return true;
    }
}

class Punto1 extends Figura{
    @Override
    public double getArea() {
     return 0.0;
    }
    @Override
    public double getVolumen() {
       return 0.0;    
    }
}

class Circulo1 extends Figura{
    int radio;
    public Circulo1(int rad){
      this.radio=rad;
    }
    @Override
    public double getArea() {
	   double area=Math.PI*Math.pow(radio,2);
	   return area;
    }
    @Override
    public double getVolumen() {
        return 0.0;
    }
}

class Cilindro extends Figura {
    int radio;
    int altura;
    public Cilindro(int rad, int alt){
       this.radio=rad;
       this.altura = alt;
    }

    @Override
    public double getArea() {
	double area=0.0;
	//area = 2 * Math.PI * (Math.pow(this.radio,2) + this.altura * 2 * Math.PI * this.radio);
    area = 2 * Math.PI * this.radio * (this.radio + this.altura);
    return area;
    }

    @Override
    public double getVolumen() {
       double volumen = Math.PI*Math.pow(this.radio,2)*this.altura;
       return volumen;
    }
}
