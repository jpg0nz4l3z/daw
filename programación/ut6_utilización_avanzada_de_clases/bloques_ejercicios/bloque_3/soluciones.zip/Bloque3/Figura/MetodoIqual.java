package POO.Bloque3.Figura;

public class MetodoIqual {

    public static void main (String[] args) {

        Cilindro cil = new Cilindro(12, 24);
        cil.setNombre("Cilindro1");
        cil.getArea();
        cil.getVolumen();

        Cilindro cil1 = new Cilindro(24, 12);
        cil1.setNombre("Cilindro2");
        cil1.getArea();
        cil1.getVolumen();

        Circulo1 cir = new Circulo1(12);
        cir.setNombre("Circulo1");
        cir.getArea();
        cir.getVolumen();

        Circulo1 cir1 = new Circulo1(24);
        cir1.setNombre("Circulo2");
        cir1.getArea();
        cir1.getVolumen();

        Punto1 punt1 = new Punto1();
        punt1.setNombre("Punto1");
        punt1.getArea();
        punt1.getVolumen();

        Punto1 punt2 = new Punto1();
        punt2.setNombre("Punto1");
        punt2.getVolumen();
        punt2.getArea();

        if(cil.equals(cil1))System.out.println("cil = cil1");
        if(cil.equals(cir))System.out.println("cil = cir");
        if(cir.equals(cir1))System.out.println("cir = cir1");
        if(cir.equals(punt1))System.out.println("cir = punt1");
        if(punt1.equals(punt2))System.out.println("punt1 = punt2");
        if(punt1.equals(cil))System.out.println("punt1 = cil");
        if(punt1.equals(punt1))System.out.println("punt1 = punt1");
    }
}
