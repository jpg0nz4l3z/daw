/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package POO.Bloque3.Figura;

public class PruebaFigura {
    public static void main(String [] args){
        Figura[] figura = {new Punto1(), new Circulo1(23), new Cilindro(23,13)};
        for(int i = 0; i <3; i++){
            figura[i].setNombre(figura[i].getClass().getName());
            System.out.println("Nombre " + figura[i].getNombre());
            System.out.println("Area " + figura[i].getArea());
            System.out.println("Volumen " + figura[i].getVolumen());
            System.out.println("");
        }
    }
}
