package POO.Bloque3.Hablador;

public class Animal implements Hablador{
    public void saluda(){};
}
