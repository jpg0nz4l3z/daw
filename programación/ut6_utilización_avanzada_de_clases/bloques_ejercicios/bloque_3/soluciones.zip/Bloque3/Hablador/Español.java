package POO.Bloque3.Hablador;

public class Español extends Persona implements Hablador{
    public Español(String nombre, String apellidos){
        super.nombre = nombre;
        super.apellidos = apellidos;
    }
    public void saluda(){
        System.out.println("Hola, soy español");
    }
}
