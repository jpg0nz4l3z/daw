package POO.Bloque3.Hablador;

public class Gato extends Animal{
   public void saluda(){
       System.out.println("Hola, soy un gato: ¡Miau!");
   }
}
