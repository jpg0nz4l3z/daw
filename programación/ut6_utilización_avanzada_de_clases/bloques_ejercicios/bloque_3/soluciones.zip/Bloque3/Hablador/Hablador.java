package POO.Bloque3.Hablador;

public interface Hablador {
    public void saluda();
}
