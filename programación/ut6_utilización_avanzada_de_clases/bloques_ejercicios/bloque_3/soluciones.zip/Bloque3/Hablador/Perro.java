package POO.Bloque3.Hablador;

public class Perro extends Animal{
  public void saluda(){
      System.out.println("Hola Soy un perro: ¡Guau!");
  }
}
