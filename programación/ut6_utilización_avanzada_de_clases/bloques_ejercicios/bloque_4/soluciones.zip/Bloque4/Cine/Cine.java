/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package POO.Bloque4.Cine;

/**
 *
 * @author Jorge Florentino
 */
public class Cine {
    int filas,columnas;
    String pelicula;
    double precioentrada;
    boolean [][] libres;
    public Cine(){}
    public Cine(int filas, int columnas, double precio){
       this.filas=filas;
       this.columnas=columnas;
       this.precioentrada=precio;
    }
    public Cine(int fil, int col, String peli, double prec){
       this.filas = fil;
       this.columnas = col;
       this.pelicula = peli;
       this.precioentrada = prec;
       
    }
    
    //metodo para rellenar los asientos con las etiquetas y poner todos como libres
    //Sólo se ejecuta la primera vez.
    public boolean[][] numerarAsientos(String [][] asientos){
	libres = new boolean[filas][columnas];	
       int m;     
       for(int i = 0; i<filas; i++){
	      m=0;
	      for(char a = 'A'; a <=(char)(columnas+64); a++,m++){
	         asientos[i][m]= Integer.toString(filas-i)+a;
	         libres[i][m]=true;
	         System.out.print(asientos[i][m] + "  ");
	      }
	      System.out.println("\n");
       }  
       return libres;
    }
    
    //Metodo que nos indica si hay asientos libres.
    public boolean hayasientos(boolean[][]libres){
	    boolean libre=false;
        int ocupado=0;
	    //Recorremos todos los asientos.
	    for(int i=0; i<this.filas;i++){
	        for(int j=0; j<this.columnas;j++){
	        //si el asiento no está libre, sumar uno al contador de ocupados.
	            if(libres[i][j])libre=true;
	        }
	    }
        return libre;
    }        
}

//La clase película hereda de Cine.
class pelicula extends Cine{
   String titulo;
   double duracion;
   int edadmin;
   String director;
   public pelicula(){}
   public pelicula(int edadmin, int fil, int col, double prec){
      super(fil,col,prec);
     this.edadmin=edadmin;
   }
   public pelicula(double dur, int edmin, String dir, int fil, int col, String peli, double prec){
       super(fil, col, peli, prec);
       this.duracion = dur;
      this.edadmin = edmin;
      this.director = dir;
   }
}

//La clase espectador hereda de pelicula.
class espectador extends pelicula{
   String nombre;
   int edad;
   double dinero;
   String posicion;
   espectador(){}
   //El constructor espectador tiene todos los atributos propios y heredados.
   public espectador(String nom, int edad, double dinero, int edmin, int fil, int col,double prec){
      super(edmin,fil,col, prec);
      this.nombre=nom;
      this.edad = edad;
      this.dinero=dinero;
   }
   
   //Este método indica si puede sentarse el espectador: si tiene dinero suficiente
   //si hay asientos libres y si tiene la edad mínima requerida.
   public boolean puedesentarse(boolean [][]libres){
       boolean puede= this.dinero >= super.precioentrada && super.hayasientos(libres) && this.edad >= super.edadmin;
       return puede;
   }
   
   //Asigna butaca a un espectador siempre que pueda sentarse y esté libre la butaca 
   //que vemos si esa posición del array libre está true.
   public String posicion(int fila, int columna, boolean[][]libres, String[][]asientos){
      if(puedesentarse(libres)){	  
         if(libres[fila][columna]){
            posicion=asientos[fila][columna];
	        libres[fila][columna]=false;
         } else posicion="ocupado";
      } else posicion="No tiene acceso";
      return posicion;
   }
}
