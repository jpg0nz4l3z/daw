/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package POO.Bloque4.Cine;


import POO.Bloque4.Cine.Cine;
import POO.Bloque4.Cine.espectador;
import POO.Bloque4.Cine.pelicula;

public class CineExec {
    static int filas=4;
    static int columnas=4;
    //método para sentar a un nuevo espectador en su asiento siempre que pueda.
    //Si está ocupado el asiento, se vuelve a ejecutar hasta que encuentre uno libre.
    //Para hacer esto, usamos recursividad
    public static void sentarse(espectador espec, boolean [][] lib, String [][] asientos){
        int posfil= (int)(Math.random()*filas);
        int poscol = (int)(Math.random()*columnas);
        System.out.println(asientos[posfil][poscol]);
    
        String posc = espec.posicion(posfil, poscol, lib, asientos);
        if(!posc.equals("No tiene acceso")){
	        if(!posc.equals("ocupado")){
	            System.out.println(espec.nombre + " tiene asignada esta posición: "+ posc);
	        }
	        else {
	            System.out.println(posc + " Este asiento ya está asignado, busque otro: ");
	            //Llamamos al método desde dentro del mismo método hasta que se cumpla el objetivo.
	            sentarse(espec, lib, asientos);
	        }
        }else System.out.println(espec.nombre + " " + posc);
    }
    
    public static void main(String[] args){
        Cine cine = new Cine(filas,columnas,"El árbol del ahorcado",10.0);
        //Dos arrays bidimensinales, uno para las etiquetas de las butacas, otro para ver si está libre el asiento.
        String [][]asientos = new String[cine.filas][cine.columnas];
        boolean[][]lib= cine.numerarAsientos(asientos);
        //Creamos un objeto pelicula con todos loa atributos propios y heredados de Cine.
        pelicula peli = new pelicula(2.6, 16, "Sada Deli",cine.filas, cine.columnas, cine.pelicula, cine.precioentrada);
        //Ceamos distintos objetos espectador con los atributos que necesitamos propios y heredados de pelicula.
        //En cada uno de ellos llamamos al método sentarse() al que incluimos el objeto, array libre y array asientos.
        espectador uno = new espectador("Juan", 16, 30.0,peli.edadmin,peli.filas,peli.columnas,peli.precioentrada);
        sentarse(uno, lib, asientos);
        espectador dos = new espectador("Antonio", 23, 30.0, peli.edadmin,peli.filas,peli.columnas,peli.precioentrada);
        sentarse(dos, lib, asientos);
        espectador tres = new espectador("Jaime", 36, 34.0, peli.edadmin,peli.filas,peli.columnas,peli.precioentrada);
        sentarse(tres, lib, asientos);
        espectador cuatro = new espectador("Jesús", 26, 3.0,peli.edadmin,peli.filas,peli.columnas,peli.precioentrada);
        sentarse(cuatro, lib, asientos);
        espectador cinco = new espectador("Adela", 18, 23.0,peli.edadmin, peli.filas,peli.columnas,peli.precioentrada);
        sentarse(cinco, lib, asientos);
    }
}
