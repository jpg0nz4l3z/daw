package POO.Bloque4.Cuenta_Total;


    public class Cuenta {
        String titular;
        double cantidad;

        public Cuenta(String ti, double cant){
            this.titular=ti;
            this.cantidad=cant;
        }
        public void setTitular(String tit){this.titular = tit;}
        public String getTitular(){return titular;}
        private void setCantidad(double din){this.cantidad=din;}
        private double getCantidad(){return cantidad;}

        public void mostrar(){
            System.out.println("Titular: "+getTitular());
            System.out.println("Dinero en cuenta: " + getCantidad() + "€");
        }
        public void ingresar(double dinero){
            double nueva_cantidad = getCantidad() + dinero;
            if (dinero >=0) setCantidad(nueva_cantidad);
        }
        public void retirar(double dinero){
            double nueva_cantidad = getCantidad() - dinero;
            setCantidad(nueva_cantidad);
        }

    }


