package POO.Bloque4.Cuenta_Total;

public class CuentaJoven extends Cuenta{
        double bonificacion;
        int edad;
        public CuentaJoven(int edad, double boni, String ti, double cant){
            super(ti,cant);
            this.edad=edad;
            this.bonificacion=boni;}
        private CuentaJoven(String ti, double cant) {
            super(ti,cant);
        }
        public void setBonificacion(double bonif){this.bonificacion=bonif;}
        public double getBonificacion(){return bonificacion;}

        public boolean titularValido(){
            boolean positivo;
            positivo= edad >= 18 && edad < 25;
            return positivo;
        }

        public void retirar(double cantidad){
            if (titularValido()){
                super.retirar(cantidad);
            }
        }

        public void mostrar(){
            super.mostrar();
            if (titularValido()){
                System.out.println("CUENTA JOVEN");
                System.out.println("Bonificacion: " + getBonificacion() + "%");
            }
            else System.out.println("No puede tener una CuentaJoven debido a su edad " + edad);
        }
    }

