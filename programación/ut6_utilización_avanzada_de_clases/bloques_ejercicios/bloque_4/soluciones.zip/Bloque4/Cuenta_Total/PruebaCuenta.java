package POO.Bloque4.Cuenta_Total;

public class PruebaCuenta {
    public static void main (String[] args){

        Cuenta cliente = new Cuenta("Jorge",5000);
        cliente.setTitular("TitularCuenta1");
        cliente.ingresar(2000);
        cliente.mostrar();
        double dineroRetirar = 2000;
        System.out.println("Ahora el cliente " + cliente.getTitular() + " va a retirar " + dineroRetirar + "€");
        cliente.retirar(dineroRetirar);
        cliente.mostrar();
        double dineroIngresar = 5500.25;
        System.out.println("Ahora el cliente " + cliente.getTitular() + " va a ingresar " + dineroIngresar + "€");
        cliente.ingresar(dineroIngresar);
        cliente.mostrar();

        System.out.println();

        CuentaJoven cliente1 = new CuentaJoven(24, 30,"Jorge",5000);
        cliente1.setTitular("TitularCuentaJoven1");
        cliente1.setBonificacion(30);
        cliente1.ingresar(18000);
        cliente1.mostrar();
        cliente1.retirar(20000);
        cliente1.mostrar();

        System.out.println();

        Cuenta cliente2 = new CuentaJoven(30,30.5,"Jorge",80022);
        cliente2.setTitular("TitularCuentaJoven2");
        ((CuentaJoven)cliente2).setBonificacion(30);
        cliente2.ingresar(12000);
        cliente2.mostrar();
        cliente2.retirar(20000);
        cliente2.mostrar();

    }
}
