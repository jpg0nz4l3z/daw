/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package POO.Bloque4.Electrodomesticos;

/**
 *
 * @author Jorge Florentino
 */
public class Electrodomestico {
    String color;
    protected static final String COLOR_POR_DEFECTO = "blanco";
    char consumo_energetico;
    protected static final char CONSUMO_POR_DEFECTO = 'F';
    double precio_base;
    protected static final double PRECIO_BASE_POR_DEFECTO = 100.0;
    double peso;
    protected static final double PESO_POR_DEFECTO = 5.0;

    public Electrodomestico(){
        this.color=COLOR_POR_DEFECTO;
        this.consumo_energetico=CONSUMO_POR_DEFECTO;
        this.peso=PESO_POR_DEFECTO;
        this.precio_base=PRECIO_BASE_POR_DEFECTO;
    }
    public Electrodomestico(double precio, double peso){
       this.precio_base=precio;
       this.peso=peso;
       this.color=COLOR_POR_DEFECTO;
       this.consumo_energetico=CONSUMO_POR_DEFECTO;
    }
    
    public Electrodomestico(double precio, double peso, char consumo, String col){
       this.precio_base=precio;
       this.peso=peso;
       comprobarConsumoenergetico(consumo);//solo puede tener de la A a la F.
       comprobarColor(col);//sólo puede incluirse blanco,rojo,negro,azul y gris.
    }
    
    public String getcolor(){return color;}
    public double getprecio_base(){return precio_base;}
    public double getpeso(){return peso;}
    public char getconsumo_energetico(){return consumo_energetico;}
    
    public void comprobarConsumoenergetico(char b){
	    boolean cont=false;
	    for(char a = 'A'; a <= 'F'; a++){
            if (a == b) {
                cont = true;
                break;
            }
        }
	    if(!cont)this.consumo_energetico='A';
	    else this.consumo_energetico=b;
   }
    
    public void comprobarColor(String c){
        boolean cont = false;
        String [] colores = {"blanco","rojo","negro","azul","gris"};
	    for (String colore : colores) {
            if (colore.equals(c)) {
                cont = true;
                break;
            }
	    }
       if(cont) this.color=c;
    }
    

    public double precioFinal(){
	    double precio = getprecio_base();
	    int m=0;
	    int [] cont = {100, 80, 60, 50, 30, 10};
        for(char i = 'A'; i<='F'; i++,m++){
	        if (i==getconsumo_energetico()){
	            if(getpeso()<20) precio += cont[m] + 10;
		        else if(getpeso()<50) precio += cont[m] + 50;
		        else if(getpeso()<80) precio += cont[m] + 80;
		        else precio += cont[m] + 100;
	        }
	    }
	    return precio;
    }
}



