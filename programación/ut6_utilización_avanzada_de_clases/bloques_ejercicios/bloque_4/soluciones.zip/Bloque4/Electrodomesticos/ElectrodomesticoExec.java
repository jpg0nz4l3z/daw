package POO.Bloque4.Electrodomesticos;

import POO.Bloque4.Electrodomesticos.Electrodomestico;
import POO.Bloque4.Electrodomesticos.Lavadora;
import POO.Bloque4.Electrodomesticos.Television;

public class ElectrodomesticoExec {
    public static void main(String [] args){
       Electrodomestico[] ArrayElectd= new Electrodomestico[4];
       ArrayElectd[0] = new Lavadora(100.0,20.3,'F',"azul",20.4);
       ArrayElectd[1] = new Television(200.0,7.2,'F',"negro",30,true);
       ArrayElectd[2] = new Electrodomestico(200.0,40.3,'F',"azul");
       ArrayElectd[3] = new Electrodomestico(600.0,78.9,'M',"marron");
       
       double precioLav = 0.0, precioTel = 0.0, precioElect = 0.0, valor;

       for (Electrodomestico ArrayElectd1 : ArrayElectd) {
	       valor = ArrayElectd1.precioFinal();
	       if (ArrayElectd1.getClass().getSimpleName().equals("Lavadora")) precioLav += valor;
	       if (ArrayElectd1.getClass().getSimpleName().equals("Television")) precioTel += valor;
	       if (ArrayElectd1.getClass().getSimpleName().equals("Electrodomestico")) precioElect += valor;
       }
       System.out.println("El precio de las lavadoras es: " + precioLav);
       System.out.println("El precio de los Televisores es: " + precioTel);
       System.out.println("El precio de los Electrodomesticos es: " + precioElect);
       System.out.println("El precio total de todos los electrodomesticos es: " + (precioLav + precioTel + precioElect));
    }
}
