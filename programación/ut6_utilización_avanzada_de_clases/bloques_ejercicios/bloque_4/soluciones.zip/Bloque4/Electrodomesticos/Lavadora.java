package POO.Bloque4.Electrodomesticos;

public class Lavadora extends Electrodomestico {
        public static final double CARGA_PERMITIDA=5;
        double carga;
        public Lavadora(double precio, double peso, char consu, String col, double carga) {
            super(precio, peso, consu, col);
            this.carga = carga;
        }

        public Lavadora(){
            super();
            this.carga = CARGA_PERMITIDA;
        }

    public Lavadora(double peso,double precio){
            super(precio,peso);
            this.carga=CARGA_PERMITIDA;
        }

        public double getcarga(){return this.carga;}
        @Override
        public double precioFinal(){
            double precio = super.precioFinal();
            if(getcarga()>30) precio += 50;
            return precio;
        }
    }

