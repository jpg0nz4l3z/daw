package POO.Bloque4.Electrodomesticos;

public class Television extends Electrodomestico{
        int resolucion;
        public static final int RESOLUCION_POR_DEFECTO=20;
        boolean sintonizadorTDT;
        public static final boolean SINTONIZADORTDT_POR_DEFECTO=false;
        public Television(){
            super();
            this.resolucion=RESOLUCION_POR_DEFECTO;
            this.sintonizadorTDT=SINTONIZADORTDT_POR_DEFECTO;
        }
        public Television(double peso, double precio){
            super(precio,peso);
            this.resolucion=RESOLUCION_POR_DEFECTO;
            this.sintonizadorTDT=SINTONIZADORTDT_POR_DEFECTO;
        }
        public Television(double precio, double peso, char consu, String col, int res, boolean sint){
            super(precio, peso, consu, col);
            this.resolucion=res;
            this.sintonizadorTDT=sint;
        }
        public int getresolucion(){return this.resolucion;}
        public boolean getsintonizadorTDT(){return this.sintonizadorTDT;}
        @Override
        public double precioFinal(){
            double precio = super.precioFinal();
            if(getresolucion() > 40) precio *= 1.3;
            if(getsintonizadorTDT()) precio += 50;
            return precio;
        }
    }

