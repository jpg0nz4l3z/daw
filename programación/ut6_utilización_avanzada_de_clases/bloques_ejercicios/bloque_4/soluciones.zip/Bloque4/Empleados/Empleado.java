/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package POO.Bloque4.Empleados;

/**
 *
 * @author Jorge Florentino
 */
public class Empleado {
    String nombre;
    String apellidos;
    long seguridad_social;
    int salario_base;
    public Empleado(String nom, String aps, long segsoc, int salbas){
       this.nombre = nom;
       this.apellidos = aps;
       this.seguridad_social=segsoc;
       this.salario_base=salbas;
    }
    public int getSalario(){
       return this.salario_base;
    }
}

class EmpleadoPorComision extends Empleado{
   int num_ventas;
   int com_ventas;
   public EmpleadoPorComision(String nom, String aps, long segsoc, int salbas, int numv, int comv){
      super(nom,aps,segsoc,0);
      this.num_ventas = numv;
      this.com_ventas = comv;
   }
   @Override
   public int getSalario(){
      return this.num_ventas*this.com_ventas;
   }
}

class EmpleadoBaseMasComision extends EmpleadoPorComision{
   public EmpleadoBaseMasComision(String nom, String aps, long segsoc, int salbas, int numv, int comv){
      super(nom,aps,segsoc,salbas, numv, comv);
      this.salario_base = salbas;
   }
   @Override
   public int getSalario(){
       int saltotal = super.getSalario()+this.salario_base;
       return saltotal;
   }
}