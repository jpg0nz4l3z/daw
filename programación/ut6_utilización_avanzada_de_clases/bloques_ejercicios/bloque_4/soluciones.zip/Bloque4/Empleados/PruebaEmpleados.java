/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package POO.Bloque4.Empleados;

import POO.Bloque4.Empleados.EmpleadoBaseMasComision;
import POO.Bloque4.Empleados.EmpleadoPorComision;

/**
 *
 * @author Jorge Florentino
 */
public class PruebaEmpleados {
    public static void main(String [] args){
       String nom="Jorge";
       String aps="Duran Poblador";
       long segs = 1100001112;
       int salb = 0;
       int numven = 26;
       int comven = 3000;
       EmpleadoPorComision empcom1= new EmpleadoPorComision(nom,aps,segs,salb,numven,comven);
       nom="Carlos";
       aps="Martín Anton";
       segs = 133000112;
       salb = 0;
       numven = 38;
       comven = 5000;
       EmpleadoPorComision empcom2= new EmpleadoPorComision(nom,aps,segs,salb,numven,comven);

       nom="Jaime";
       aps="Diaz Paez";
       segs = 1340001212;
       salb = 70000;
       numven = 16;
       comven = 2000;
       EmpleadoBaseMasComision empbasecom1= new EmpleadoBaseMasComision(nom,aps,segs,salb,numven,comven);
       nom="Carmen";
       aps="Martinez Antunez";
       segs = 1650837644;
       salb = 80000;
       numven = 45;
       comven = 4000;
       EmpleadoBaseMasComision empbasecom2= new EmpleadoBaseMasComision(nom,aps,segs,salb,numven,comven);
       
       System.out.println("Nombre: " + empcom1.nombre + " " + empcom1.apellidos + ", Salario: " + empcom1.getSalario());
       System.out.println("Nombre: " + empcom2.nombre + " " + empcom2.apellidos + ", Salario: " + empcom2.getSalario());
       System.out.println("Nombre: " + empbasecom1.nombre + " " + empbasecom1.apellidos + ", Salario: " + empbasecom1.getSalario());
       System.out.println("Nombre: " + empbasecom2.nombre + " " + empbasecom2.apellidos + ", Salario: " + empbasecom2.getSalario());

    }
}
