
package POO.Bloque4.Libro;
//ejercicio 15.
public class Libro {
    String ISBN,Titulo,Autor;
    int numpag;
    public void setISBN(String is){this.ISBN=is;}
    public String getISBN(){return ISBN;}
    public void setTItulo(String ti){this.Titulo=ti;}
    public String getTitulo(){return Titulo;}
    public void setAutor(String au){this.Autor=au;}
    public String getAutor(){return Autor;}
    public void setNumpag(int num){this.numpag=num;}
    public int getNumpag(){return numpag;}
    public void LibrotoString(){
       System.out.println("El libro con ISBN " + getISBN()+ ", creado por el autor "+ getAutor() +" tiene " + getNumpag() +" páginas");
    }
}
