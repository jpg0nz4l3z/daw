package POO.Bloque4.Libro;

public class ProbarLibro {
    public static void compararLibros(Libro lib1, Libro lib2){
        if(lib1.getNumpag()>lib2.getNumpag())
            System.out.println("El libro " + lib1.getTitulo() + " tiene más páginas que el libro " + lib2.getTitulo());
        else if(lib2.getNumpag()>lib1.getNumpag())
            System.out.println("El libro \"" + lib2.getTitulo() + "\" tiene más páginas que el libro \"" + lib1.getTitulo() + "\"");
        else
            System.out.println("Los dos libros tienen las mismas páginas.");
    }

    public static void main (String [] args){
        Libro libro1 = new Libro();
        libro1.setAutor("Jorge F Durán");
        libro1.setISBN("B12345");
        libro1.setNumpag(456);
        libro1.setTItulo("Lo que ha de venir.");
        libro1.LibrotoString();

        Libro libro2 = new Libro();
        libro2.setAutor("Jorge F Durán");
        libro2.setISBN("B12231");
        libro2.setNumpag(927);
        libro2.setTItulo("Que venga.");
        libro2.LibrotoString();

        compararLibros(libro1,libro2);
     }
}
