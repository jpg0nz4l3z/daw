package POO.Bloque4.OrdenarArray;
import java.util.Scanner;
import java.util.Random;
public class OrdenarArray {
        public static void main(String[] args) {
            Scanner scanner = new Scanner(System.in);
            Random random = new Random();

            // Pedir tamaño del array
            System.out.print("Ingrese el tamaño del array: ");
            int n = scanner.nextInt();

            // Generar array de números reales aleatorios
            double[] array = new double[n];
            for (int i = 0; i < n; i++) {
                array[i] = random.nextDouble() * 100; // Números entre 0 y 100
            }

            // Mostrar array original
            System.out.println("Array generado:");
            imprimirArray(array);

            // Preguntar al usuario por el método de ordenación
            System.out.println("Elija el método de ordenación:");
            System.out.println("1. Burbuja");
            System.out.println("2. Quicksort");
            int opcion = scanner.nextInt();

            // Ordenar según la elección del usuario
            switch (opcion) {
                case 1:
                    ordenarBurbuja(array);
                    break;
                case 2:
                    quicksort(array, 0, array.length - 1);
                    break;
                default:
                    System.out.println("Opción no válida. Finalizando programa.");
                    return;
            }

            // Mostrar array ordenado
            System.out.println("Array ordenado:");
            imprimirArray(array);
        }

        // Método para ordenar con el algoritmo de la burbuja
        public static void ordenarBurbuja(double[] array) {
            int n = array.length;
            for (int i = 0; i < n - 1; i++) {
                for (int j = 0; j < n - i - 1; j++) {
                    if (array[j] > array[j + 1]) {
                        // Intercambiar
                        double temp = array[j];
                        array[j] = array[j + 1];
                        array[j + 1] = temp;
                    }
                }
            }
        }

        // Método para ordenar con quicksort
        public static void quicksort(double[] array, int inicio, int fin) {
            if (inicio < fin) {
                int indicePivote = particion(array, inicio, fin);
                quicksort(array, inicio, indicePivote - 1);
                quicksort(array, indicePivote + 1, fin);
            }
        }

        // Método auxiliar para particionar el array en quicksort
        public static int particion(double[] array, int inicio, int fin) {
            double pivote = array[fin];
            int i = inicio - 1;
            for (int j = inicio; j < fin; j++) {
                if (array[j] <= pivote) {
                    i++;
                    // Intercambiar
                    double temp = array[i];
                    array[i] = array[j];
                    array[j] = temp;
                }
            }
            // Intercambiar el pivote con el elemento siguiente a i
            double temp = array[i + 1];
            array[i + 1] = array[fin];
            array[fin] = temp;
            return i + 1;
        }

        // Método para imprimir el array
        public static void imprimirArray(double[] array) {
            for (double num : array) {
                System.out.printf("%.2f ", num);
            }
            System.out.println();
        }
}


