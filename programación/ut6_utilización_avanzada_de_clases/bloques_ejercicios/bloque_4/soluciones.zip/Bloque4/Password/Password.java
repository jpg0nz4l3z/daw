/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package POO.Bloque4.Password;

/**
 *
 * @author Jorge Florentino
 */
public class Password {
    int longitud = 8;
    String contraseña="";
    String LetrasyNumeros = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZabcdefghijklmnñopqrstuvwxyz";

    public Password(){}
    public Password(int longit){
	    for (int i = 0; i < longit; i++){
	        contraseña = contraseña + LetrasyNumeros.charAt((int)(Math.random()*63 + 1));
	    }
    }
    public String getContraseña(){return contraseña;}
    public void getLongitud(){}
    public void setLongitud(int longit){this.longitud=longit;}
    public boolean esFuerte(){
	    boolean fuerte;
	    int may=0,num=0,min=0;
	    for(int i=0; i<contraseña.length();i++){
	        for(int j = 0; j < 9;j++)
	            if(contraseña.charAt(i)==LetrasyNumeros.charAt(j)) num++;
                if(contraseña.toUpperCase().charAt(i)==contraseña.charAt(i)) may++;
                if(contraseña.toLowerCase().charAt(i)==contraseña.charAt(i)) min++;
        }
        fuerte = may > 2 && min > 1 && num > 5;
	return fuerte;
 }
    public String generarPassword(){
       return contraseña;
    }
}
