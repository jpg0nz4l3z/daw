/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package POO.Bloque4.Password;

import java.util.Scanner;

public class PasswordExec {
    public static void main(String[] args){
       System.out.println("Dígame el número de password que quiere generar ");
       Scanner sc = new Scanner(System.in);
       int numPass= sc.nextInt();
       String [] arrayPsw = new String[numPass];
       boolean [] arrayFuerte = new boolean[numPass];
       System.out.println("Deme ahora la longitud de los password del array");
       int tamCont = sc.nextInt();
       for(int i = 0; i < arrayPsw.length; i++){
	       Password ps = new Password(tamCont);
	       arrayPsw[i]=ps.generarPassword();
	       arrayFuerte[i]=ps.esFuerte();
	       System.out.println(arrayPsw[i] + " ->" + arrayFuerte[i]);
       }
    }
}
