/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package POO.Bloque4.Password;

import java.util.Scanner;

/**
 *
 * @author Jorge Florentino
 */
public class password1 {

    int longitud=8;
    String contrasena;

    public password1() {
        this.contrasena="";
    }
   
    public password1(int ln) {
        this.contrasena="";
        int cont;
        longitud=ln;
        for(int i=0;i<this.longitud;i++){
            cont=(int) (Math.random() * (123 - 48 + 1) + 48);
            this.contrasena += Character.toString((char)cont);
        }
    }

    public int getLongitud() {
        return longitud;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setLongitud(int longitud) {
        this.longitud = longitud;
    }
    
    public boolean esFuerte(String cont){
        char [] numeros={'0','1','2','3','4','5','6','7','8','9'};
        int mayus=0;
        int minus=0;
        int num=0;
        for(int i=0;i<cont.length();i++){
            if(cont.toLowerCase().charAt(i)==cont.charAt(i)){
                minus+=1;
            } else if(cont.toUpperCase().charAt(i)==cont.charAt(i)){
                mayus+=1;
            } else {
                for (int j = 0; j < numeros.length; j++) {
                    if (numeros[j] == cont.charAt(i)) {
                        num++;
                    }
                }
            }
        }
        return minus > 1 && mayus > 2 && num > 5;
    }
    
    public void generarPassword(){
        int cont;
        for(int i=0;i<this.longitud;i++){
            cont=(int) (Math.random() * (123 - 48 + 1) + 48);
            this.contrasena+= Character.toString((char)cont);
        }
    }
    
    public static void main(String[] args) {
        Scanner read=new Scanner(System.in);
        int longitudcont;
        int longitud;
        System.out.println("pon longitud de contraseÃ±a");
        longitudcont=read.nextInt();
        System.out.println("pon longitud de array");
        int tamanio= read.nextInt();
        boolean []fuerte=new boolean[tamanio];
        password1 [] arr= new password1[tamanio];
        for (int j=0;j<tamanio;j++){
            arr[j]=new password1();
            arr[j].setLongitud(longitudcont);
            arr[j].generarPassword();
            fuerte[j]=arr[j].esFuerte(arr[j].getContrasena());
        }
        for (int i=0; i<tamanio;i++){
            System.out.println(arr[i].getContrasena()+" "+fuerte[i]);
        }
    }
 
}
