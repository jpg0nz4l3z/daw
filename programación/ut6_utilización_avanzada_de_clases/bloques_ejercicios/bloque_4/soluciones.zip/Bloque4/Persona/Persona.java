package POO.Bloque4.Persona;

public class Persona {
   String nombre, DNI=generaDNI(), sexo="H";
   int edad;
   double peso, altura = 0;
   public Persona(){}
   public Persona(String nom, int ed, String sex){
       this.nombre=nom;
       this.edad=ed;
       this.sexo=comprobarSexo(sex);
   }
   public Persona(String nom, String DNI, int peso, int altura, int ed, String sex){
       this.nombre = nom;
       this.DNI=DNI;
       this.peso=peso;
       this.sexo=comprobarSexo(sex);
       this.altura=altura;
       this.edad=ed;
   }

    public int calcularIMC(){
        int form = (int) ((int) peso/Math.pow(altura,2));
        if(form<20) return -1;
        else if(form>=20 && form<=25) return 0;
        else return 1;
    }
    public boolean esMayorDeEdad(){
       boolean mayor= edad >= 18;
        return mayor;
    }
    public String comprobarSexo(String sexo){
       if (sexo.equals("H")||sexo.equals("M")){
           System.out.println("El sexo se ha introducido correctamente");
           return sexo;
       } else return "H";
    }

    @Override
    public String toString() {
        return "Persona{" +
                "nombre='" + nombre + '\'' +
                ", DNI='" + DNI + '\'' +
                ", sexo='" + sexo + '\'' +
                ", edad=" + edad +
                ", peso=" + peso +
                ", altura=" + altura +
                '}';
    }

    public static String generaDNI(){
        int numDNI = (int) (Math.random()*100000000);
        char [] caracteres = {'T','R','W','A','G','M','Y','F','P','D','X','B','N',
                'J','Z','S','Q','V','H','L','C','K','E'};
        int resto = numDNI %23;
        char letra = caracteres[resto];
        String numDNI8 = String.format("%08d", numDNI);
        return numDNI8+letra;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setSexo(String sexo) {
        this.sexo = comprobarSexo(sexo);
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }
}