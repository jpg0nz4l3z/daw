package POO.Bloque4.Persona;

import java.util.Scanner;

public class ProbarPersona {
    public static void pesoIdeal(Persona pr){
        if(pr.calcularIMC()==-1)System.out.println("Estás por debajo de tu peso ideal");
        else if(pr.calcularIMC()==0)System.out.println("Estás en tu peso ideal");
        else System.out.println("Estás por encima de tu peso ideal");
    }

    public static void mayor(Persona pr){
        if(pr.esMayorDeEdad())System.out.println("Eres mayor de edad.");
        else System.out.println("No eres mayor de edad.");
    }

    public static void main (String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Dame el nombre del sujero: ");
        String nombre = sc.nextLine();
        System.out.println("Dame ahora la edad: ");
        int edad = sc.nextInt();
        sc.nextLine();
        System.out.println("sexo: ");
        String sexo = sc.nextLine();
        System.out.println("Peso: ");
        int peso = sc.nextInt();
        System.out.println("Altura: ");
        int altura = sc.nextInt();
        sc.nextLine();
        String DNI = Persona.generaDNI();

        Persona pr = new Persona(nombre,DNI,peso,altura,edad,sexo);
        System.out.println(pr);
        pesoIdeal(pr);
        mayor(pr);


        Persona pr1 = new Persona(nombre,edad,sexo);
        System.out.println(pr1);
        pesoIdeal(pr1);
        mayor(pr1);


        Persona pr2 = new Persona();
        pr2.setEdad(edad);
        pr2.setAltura(altura);
        pr2.setNombre(nombre);
        pr2.setPeso(peso);
        pr2.setSexo(sexo);
        System.out.println(pr2);
        pesoIdeal(pr2);
        mayor(pr2);

    }
}
