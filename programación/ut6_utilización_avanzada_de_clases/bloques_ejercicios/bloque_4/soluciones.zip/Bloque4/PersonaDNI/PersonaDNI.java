/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package POO.Bloque4.PersonaDNI;

import java.util.Scanner;

//Ejercicio 7.
public class PersonaDNI {
    String nombre,DNI;
    int edad;
    public void setNombre(String nomb){this.nombre=nomb;}
    public String getNombre(){return nombre;}
    public void setDNI(String DNI){this.DNI = DNI;}
    public String getDNI(){return DNI;}
    public void setEdad(int edad){this.edad=edad;}
    public int getEdad(){return edad;}
    public void mostrar(){
       System.out.println("Nombre: " + getNombre());
       System.out.println("DNI: " + getDNI());
       System.out.println("Edad: " + getEdad());
    }
    public boolean esMayorDeEdad(){
	    boolean mayor = getEdad() >= 18;
        return mayor;
    }
    
    public static void main(String [] args){
       Scanner sc = new Scanner(System.in);	
       PersonaDNI persona = new PersonaDNI();
       //int i=0;
        System.out.println("introduzca los datos de la persona ");
	    System.out.print("Nombre: ");
	    persona.setNombre(sc.nextLine());
	    System.out.print("DNI: ");
	    persona.setDNI(sc.nextLine());
	    System.out.print("Edad: ");
	    persona.setEdad(sc.nextInt());
        persona.mostrar();
        if (persona.esMayorDeEdad()) {
	        System.out.println("Es mayor de edad.");
        } else {
	        System.out.println("Aún no es mayor de adad.");
        }
    }
}
   
