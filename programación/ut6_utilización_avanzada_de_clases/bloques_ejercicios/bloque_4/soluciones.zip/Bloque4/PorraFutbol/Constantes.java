package POO.Bloque4.PorraFutbol;

public interface Constantes {
    int NUMERO_PARTIDOS=2;

    int NUMERO_JORNADAS=38;
    double DINERO_INICIAL=35;

    int RESULTADO_MINIMO=0;
    int RESULTADO_MAXIMO=9;

    double DINERO_CADA_JORNADA=1;

    Jugador[] JUGADORES={
            new Jugador("Make"),
            new Jugador("JuanMa"),
            new Jugador("Fernando"),
            new Jugador("Alberto"),
            new Jugador("Lorente"),
            new Jugador("Adrian"),
            new Jugador("Maria"),
            new Jugador("Parra"),
            new Jugador("Pablo"),
            new Jugador("Prieto"),
            new Jugador("Ruben"),
            new Jugador("Jony"),
            new Jugador("Fran"),
            new Jugador("Isidoro"),
            new Jugador("Rafa")
    };
}
