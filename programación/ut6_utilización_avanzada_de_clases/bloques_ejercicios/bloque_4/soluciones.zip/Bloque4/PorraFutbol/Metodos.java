package POO.Bloque4.PorraFutbol;

public class Metodos {
    /*** Genera un numero aleatorio entre un minimo y un maximo */
    public static int generaNumeroAleatorio(int minimo, int maximo){
        int num=(int)Math.floor(Math.random()*(minimo-(maximo+1))+(maximo+1));
        return num;
    }
}
