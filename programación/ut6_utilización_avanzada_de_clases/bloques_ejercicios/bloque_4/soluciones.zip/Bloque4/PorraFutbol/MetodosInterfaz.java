package POO.Bloque4.PorraFutbol;

public interface MetodosInterfaz {
    void generarResultados();
}
