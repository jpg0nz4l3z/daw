package POO.Bloque4.PorraFutbol;

public class ProbarPorra {
    public static void main(String[] args) {
        POOrra p = new POOrra();
        p.jornadas();
    }
}
