package POO.Bloque4.Productos;

class No_Perecederos extends Productos{
    String tipo;

    public No_Perecederos() {
        super();
        this.tipo = "Construccion";
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return super.toString()+"\nno_perecederos{" + "tipo=" + tipo + '}';
    }

    @Override
    public double calcular(int num){
        return super.calcular(num);
    }

}
