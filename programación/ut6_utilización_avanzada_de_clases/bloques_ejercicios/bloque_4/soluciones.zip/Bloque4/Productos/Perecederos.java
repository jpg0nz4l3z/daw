package POO.Bloque4.Productos;

public class Perecederos extends Productos{
        int dia_caducar;

        public Perecederos() {

            super();
        }

        public int getDia_caducar() {

            return dia_caducar;
        }

        public void setDia_caducar(int dia_caducar) {

            this.dia_caducar = dia_caducar;
        }


        @Override
        public String toString() {

            return super.toString() + "\nperecederos{" + "dia_caducar=" + dia_caducar + '}';
        }


        @Override
        public double calcular(int num){
            double cantidad=super.calcular(num);
            if(this.getDia_caducar()==1) cantidad = super.calcular(num)/4;
            if(this.getDia_caducar()==2) cantidad = super.calcular(num)/3;
            if(this.getDia_caducar()==3) cantidad = super.calcular(num)/2;
            return cantidad;
        }
    }

