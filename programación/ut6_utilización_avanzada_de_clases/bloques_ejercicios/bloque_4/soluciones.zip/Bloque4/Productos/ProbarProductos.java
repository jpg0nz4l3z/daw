/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package POO.Bloque4.Productos;

/**
 *
 * @author Jorge Florentino
 */
public class ProbarProductos {
    public static void main(String [] args){
       Productos [] product = new Productos[5];
       product[0] = new Productos();
       product[1] = new Perecederos();
       product[2] = new No_Perecederos();
       product[3] = new Productos();
       product[4] = new No_Perecederos();
       double calculo = 0;
       int num = 0;
       double calcular=0;
       
    for(int i = 0; i < product.length;i++){
	num = (int)(Math.random()*4+1);
	product[i].setNombre("nombre"+i);
	product[i].setPrecio(Math.random()*100+1);
	if(product[i].getClass().getName().equals("POO.Bloque4.Productos.perecederos")){
	    ((Perecederos)product[i]).setDia_caducar((int)(Math.random()*3+1));
	    calcular = product[i].calcular(num);
	}else calcular = product[i].calcular(num);
	System.out.println(product[i].toString());
        System.out.println("Número de productos: " + num);
	System.out.println("Precio del producto: " + calcular);
	calculo = calculo + calcular;

	System.out.println();
    }
       System.out.println("\nPrecio total de los prodcutos:" + calculo);

    
    }
    }
