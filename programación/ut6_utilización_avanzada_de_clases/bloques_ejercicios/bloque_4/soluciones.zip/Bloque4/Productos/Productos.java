/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package POO.Bloque4.Productos;

/**
 *
 * @author Jorge Florentino
 */

//Ejercicio 22. Bloque4_POO

public class Productos {
    String nombre;
    double precio;
    public Productos() {
	   this.nombre="";
	   this.precio=0;
    }
    public String getNombre() {
	    return nombre;
    }
    public void setNombre(String nombre) {
	    this.nombre = nombre;
    }
    public double getPrecio() {
	    return precio;
    }
    public void setPrecio(double precio) {
	    this.precio = precio;
    }
    @Override
    public String toString() {
        return "Productos{" + "nombre=" + getNombre() + ", precio=" + getPrecio() + '}';
    }
    public double calcular(int num){
        return this.precio*num;
    }
}


