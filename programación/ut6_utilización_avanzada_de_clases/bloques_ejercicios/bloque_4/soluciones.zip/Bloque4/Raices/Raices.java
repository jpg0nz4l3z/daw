/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package POO.Bloque4.Raices;

/**
 *
 * @author Jorge Florentino
 */
//Ejercicio 16.
public class Raices {
    int a,b,c;
    public Raices(int a, int b, int c){
       this.a=a;
       this.b=b;
       this.c=c;
    }
    public void obtenerraices(){
      if(tieneRaices()){
	      System.out.println("Las raices de la ecuación son: " + (-b + getDiscriminante())/2*a + " y " + (-b - getDiscriminante())/2*a);
      }
    }
    
    public double getDiscriminante(){
       double disc = Math.pow(b, 2) - 4*a*c;
       return disc;
    }
    public boolean tieneRaices(){
	boolean tieneraices= getDiscriminante() > 0;
        return tieneraices;
    }
    public boolean tieneRaiz(){
       boolean tiene= getDiscriminante() == 0;
        return tiene;
    }
    public void calcular(){
	if (a==0 || getDiscriminante()<0)
	    System.out.println("La ecuación no tiene solución");
	else {
            obtenerraices();
	    if(tieneRaiz())
               System.out.println("La raíz de la ecuación es: " + -b/(2*a));
	  } 
      }  
    
    public static void main(String [] args){
	Raices raiz = new Raices(3,8,2);
	System.out.println("a= "+raiz.a +", b= "+ raiz.b +", c= "+ raiz.c + " , Discriminante= "+ raiz.getDiscriminante());
	raiz.calcular();
    }
}
    

