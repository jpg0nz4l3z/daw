
package POO.Bloque4.SIstema_Planetario;

public class SistemaPlanetario {
    double masa,densidad,diametro,distSol;
    int idPlaneta;
    String nombre;
   
    private SistemaPlanetario(int idPlaneta, double masa, double densidad, double diametro, double distSol, String nombre){
	this.densidad=densidad;
	this.masa = masa;
	this.diametro = diametro;
	this.idPlaneta = idPlaneta;
	this.nombre = nombre;
	this.distSol = distSol;
    }

    //F=G*M*m/(r1-r2)^2
    public static double atraccion(double masa1, double masa2, double dist1, double dist2){
       double fuerzaAtraccion = 6.67 * Math.pow(10, -11) *masa1 * masa2 / Math.pow((dist2-dist1),2);
       return fuerzaAtraccion;
    }
    
    
    public static void main(String [] args){
       //si consideramos que los dos planetas están alineados con el Sol, la distancia entre ambos
       //será la resta entre el más alejado al sol y el más cercano.
       SistemaPlanetario Mercurio = new SistemaPlanetario(1, 3.285*Math.pow(10,23),5430,4878, 82*Math.pow(10,6),"Mercurio");
       SistemaPlanetario Tierra = new SistemaPlanetario(2, 5.97*Math.pow(10,24),5515,12756, 150*Math.pow(10,6),"Tierra");

       System.out.println("El planeta: "+ Mercurio.nombre);
       System.out.println("con masa: "+ Mercurio.masa);
       System.out.println("y distancia al sol: "+ Mercurio.distSol);
       System.out.println("y");
       System.out.println("El planeta: "+ Tierra.nombre);
       System.out.println("con masa: "+ Tierra.masa);
       System.out.println("y distancia al sol: "+ Tierra.distSol);

       double fuerza;
       fuerza = atraccion(Mercurio.masa, Tierra.masa, Mercurio.distSol, Tierra.distSol);
       System.out.println("Presentan una fuerza de atracción mutua de: " + fuerza + " Newtons");
    }
    
}
