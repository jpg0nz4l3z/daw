package POO.Bloque4.UsoVector;
import java.util.Scanner;

public class NumberManager {
    public static void main(String[] args) {
        // Crear una instancia de la clase que maneja el array dinámico
        NumberStorage storage = new NumberStorage();
        Scanner scanner = new Scanner(System.in);
        Integer previousNumber = null;
        System.out.println("Introduce números. El programa termina si introduces dos veces seguidas el mismo número:");
        while (true) {
            // Leer un número del teclado
            System.out.print("Número: ");
            int number = scanner.nextInt();
            System.out.println(number + "El número");
            // Agregar el número al almacenamiento
            storage.addNumber(number);

            // Comprobar si el número introducido es igual al anterior
            if (previousNumber != null && previousNumber == number) {
                System.out.println("¡Dos números consecutivos iguales detectados! Finalizando programa...");
                break;
            }
            // Actualizar el número anterior
            previousNumber = number;
            // Mostrar los números introducidos
            System.out.println("Números introducidos:");
            storage.printNumbers();
        }
        scanner.close();
    }
}


