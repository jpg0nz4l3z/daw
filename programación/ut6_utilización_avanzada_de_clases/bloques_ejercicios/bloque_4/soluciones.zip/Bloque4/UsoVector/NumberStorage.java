package POO.Bloque4.UsoVector;
import java.util.Vector;
public class NumberStorage {
    private final Vector<Integer> numbers;
    // Constructor
    public NumberStorage() {
        numbers = new Vector<>();
    }
    // Método para agregar un número
    public void addNumber(int number) {
        numbers.add(number);
    }
    // Método para imprimir todos los números almacenados
    public void printNumbers() {
        for (Integer number : numbers) {
            System.out.println(number);
        }
    }
}
