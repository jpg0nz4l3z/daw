package POO.Bloque4.Vehiculo;

import java.util.Scanner;
import POO.Bloque4.Vehiculo.TiposVehiculos;

public class PruebaVehiculo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Vehiculo[] vehiculos = new Vehiculo[3];
        // Leer datos de 10 vehículos
        cargarVehiculo(scanner,vehiculos);
        // Listar los vehículos
        mostrarVehiculos(vehiculos);
        scanner.close();
    }

    public static void cargarVehiculo(Scanner scanner, Vehiculo[] vehiculos){
        for (int i = 0; i < 3; i++) {
            System.out.println("Ingrese los datos del vehículo " + (i + 1) + ":");
            System.out.print("Número de pasajeros: ");
            int numeroPasajeros = scanner.nextInt();
            System.out.print("¿Tiene tripulación? (true/false): ");
            boolean tieneTripulacion = scanner.nextBoolean();
            System.out.print("Número de ruedas: ");
            int numeroRuedas = scanner.nextInt();
            scanner.nextLine(); // Limpiar el buffer
            System.out.print("Fecha de matriculación (dd/mm/yyyy): ");
            String fechaMatriculacion = scanner.nextLine();
            System.out.print("Medio de desplazamiento (terrestre/marítimo/aéreo): ");
            String medioDesplazamiento = scanner.nextLine();
            System.out.println("Ingrese el tipo de vehículo (coche/moto/camion/bicicleta/lancha):");
            //vehiculos[i] = new Vehiculo(numeroPasajeros, tieneTripulacion, numeroRuedas, fechaMatriculacion, medioDesplazamiento);

            String tipo = scanner.nextLine().toLowerCase();
            switch (tipo) {
                case "coche":
                    System.out.print("¿Es de cinco puertas? (true/false): ");
                    boolean esDeCincoPuertas = scanner.nextBoolean();
                    scanner.nextLine();
                    TiposVehiculos tipos = new TiposVehiculos();
                    TiposVehiculos.Coche1 coche = tipos.new Coche1(numeroPasajeros, tieneTripulacion, numeroRuedas, fechaMatriculacion, medioDesplazamiento, esDeCincoPuertas);
                    vehiculos[i] = coche;
                    break;
                case "moto":
                    System.out.print("¿Tiene sidecar? (true/false): ");
                    boolean tieneSidecar = scanner.nextBoolean();
                    scanner.nextLine();
                    vehiculos[i] = new TiposVehiculos.Moto1(numeroPasajeros, tieneTripulacion, numeroRuedas, fechaMatriculacion, medioDesplazamiento, tieneSidecar);
                    break;
                case "camion":
                    System.out.print("Altura (en metros): ");
                    double altura = scanner.nextDouble();
                    scanner.nextLine();
                    vehiculos[i] = new TiposVehiculos.Camion1(numeroPasajeros, tieneTripulacion, numeroRuedas, fechaMatriculacion, medioDesplazamiento, altura);
                    break;
                case "bicicleta":
                    System.out.print("¿Es eléctrica? (true/false): ");
                    boolean esElectrica = scanner.nextBoolean();
                    scanner.nextLine();
                    vehiculos[i] = new TiposVehiculos.Bicicleta1(numeroPasajeros, tieneTripulacion, numeroRuedas, fechaMatriculacion, medioDesplazamiento, esElectrica);
                    break;
                case "lancha":
                    System.out.print("Potencia del motor (en HP): ");
                    int potenciaMotor = scanner.nextInt();
                    scanner.nextLine();
                    vehiculos[i] = new TiposVehiculos.Lancha1(numeroPasajeros, tieneTripulacion, numeroRuedas, fechaMatriculacion, medioDesplazamiento, potenciaMotor);
                    break;
                default:
                    System.out.println("Tipo de vehículo no válido. Intente de nuevo.");
                    i--; // Repetir la iteración
                    break;
            }
        }
    }
    public static void mostrarVehiculos(Vehiculo[] vehiculos){
        System.out.println("\nListado de vehículos:");
        for (int i = 0; i < vehiculos.length; i++) {
            System.out.println("Vehículo " + (i + 1) + ": " + vehiculos[i]);
        }
    }
}
