package POO.Bloque4.Vehiculo;

public class TiposVehiculos {
    class Coche1 extends Vehiculo {
        private final boolean esDeCincoPuertas;
        public Coche1(int numeroPasajeros, boolean tieneTripulacion, int numeroRuedas, String fechaMatriculacion, String medioDesplazamiento, boolean esDeCincoPuertas) {
            super(numeroPasajeros, tieneTripulacion, numeroRuedas, fechaMatriculacion, medioDesplazamiento);
            this.esDeCincoPuertas = esDeCincoPuertas;
        }
        @Override
        public String toString() {
            String tipo = this.getClass().getSimpleName();
            return tipo + ": [" +  super.toString() + ", Es de cinco puertas: " + (esDeCincoPuertas ? "Sí" : "No") + "];";
        }
    }

    static class Moto1 extends Vehiculo {
        private final boolean tieneSidecar;
        public Moto1(int numeroPasajeros, boolean tieneTripulacion, int numeroRuedas, String fechaMatriculacion, String medioDesplazamiento, boolean tieneSidecar) {
            super(numeroPasajeros, tieneTripulacion, numeroRuedas, fechaMatriculacion, medioDesplazamiento);
            this.tieneSidecar = tieneSidecar;
        }
        @Override
        public String toString() {
            String tipo = this.getClass().getSimpleName();
            return tipo + ": [" +  super.toString() + ", Tiene sidecar: " + (tieneSidecar ? "Sí" : "No") + "];";
        }
    }

    static class Camion1 extends Vehiculo {
        private final double altura;
        public Camion1(int numeroPasajeros, boolean tieneTripulacion, int numeroRuedas, String fechaMatriculacion, String medioDesplazamiento, double altura) {
            super(numeroPasajeros, tieneTripulacion, numeroRuedas, fechaMatriculacion, medioDesplazamiento);
            this.altura = altura;
        }
        @Override
        public String toString() {
            String tipo = this.getClass().getSimpleName();
            return tipo + ": [" +  super.toString() + ", Altura: " + altura + " metros];";
        }
    }

    static class Bicicleta1 extends Vehiculo {
        private final boolean esElectrica;
        public Bicicleta1(int numeroPasajeros, boolean tieneTripulacion, int numeroRuedas, String fechaMatriculacion, String medioDesplazamiento, boolean esElectrica) {
            super(numeroPasajeros, tieneTripulacion, numeroRuedas, fechaMatriculacion, medioDesplazamiento);
            this.esElectrica = esElectrica;
        }

        @Override
        public String toString() {
            String tipo = this.getClass().getSimpleName();
            return tipo + ": [ " +  super.toString() + ", Es eléctrica: " + (esElectrica ? "Sí" : "No") + "];";
        }
    }

    static class Lancha1 extends Vehiculo {
        private final int potenciaMotor;
        public Lancha1(int numeroPasajeros, boolean tieneTripulacion, int numeroRuedas, String fechaMatriculacion, String medioDesplazamiento, int potenciaMotor) {
            super(numeroPasajeros, tieneTripulacion, numeroRuedas, fechaMatriculacion, medioDesplazamiento);
            this.potenciaMotor = potenciaMotor;
        }
        @Override
        public String toString() {
            String tipo = this.getClass().getSimpleName();
            return tipo + ": [" + super.toString() + ", Potencia del motor: " + potenciaMotor + " HP];";
        }
    }
}
