/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package POO.Bloque4.Vehiculo;

import java.util.Scanner;

//ejercicio 4 POO.
public class Vehiculo {
    private final int numeroPasajeros;
    private final int numeroRuedas;
    private final boolean tieneTripulacion;
    private final String fechaMatriculacion;
    private final String medioDesplazamiento;
    // Constructor
    public Vehiculo(int numeroPasajeros, boolean tieneTripulacion, int numeroRuedas, String fechaMatriculacion, String medioDesplazamiento) {
        this.numeroPasajeros = numeroPasajeros;
        this.tieneTripulacion = tieneTripulacion;
        this.numeroRuedas = numeroRuedas;
        this.fechaMatriculacion = fechaMatriculacion;
        this.medioDesplazamiento = medioDesplazamiento;
    }

    // Métodos getter
    public int getNumeroPasajeros() {
        return numeroPasajeros;
    }

    public boolean isTieneTripulacion() {
        return tieneTripulacion;
    }

    public int getNumeroRuedas() {
        return numeroRuedas;
    }

    public String getFechaMatriculacion() {
        return fechaMatriculacion;
    }

    public String getMedioDesplazamiento() {
        return medioDesplazamiento;
    }

    @Override
    public String toString() {
        return
                "Número de pasajeros: " + numeroPasajeros +
                ", Tiene tripulación: " + (tieneTripulacion ? "Sí" : "No") +
                ", Número de ruedas: " + numeroRuedas +
                ", Fecha de matriculación: " + fechaMatriculacion +
                ", Medio de desplazamiento: " + medioDesplazamiento;
    }
}



