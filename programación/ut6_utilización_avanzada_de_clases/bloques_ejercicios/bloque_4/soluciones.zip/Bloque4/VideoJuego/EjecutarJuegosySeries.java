package POO.Bloque4.VideoJuego;

public class EjecutarJuegosySeries {
    public static void main(String[] args) {
        Serie[] series = new Serie[5];
        Videojuego[] videojuegos = new Videojuego[5];

        // Crear series
        series[0] = new Serie("Serie 1", 5, "Drama", "Creador 1");
        series[1] = new Serie("Serie 2", "Creador 2");
        series[2] = new Serie("Serie 3", 4, "Comedia", "Creador 3");
        series[3] = new Serie();
        series[4] = new Serie("Serie 4", 7, "Acción", "Creador 4");

        // Crear videojuegos
        videojuegos[0] = new Videojuego("Videojuego 1", 20, "Aventura", "Compañía 1");
        videojuegos[1] = new Videojuego("Videojuego 2", 15);
        videojuegos[2] = new Videojuego("Videojuego 3", 30, "RPG", "Compañía 3");
        videojuegos[3] = new Videojuego();
        videojuegos[4] = new Videojuego("Videojuego 4", 25, "Acción", "Compañía 4");

        // Entregar algunos elementos
        series[0].entregar();
        series[2].entregar();
        videojuegos[1].entregar();
        videojuegos[3].entregar();

        // Contar entregados
        int seriesEntregadas = 0;
        int videojuegosEntregados = 0;

        for (Serie serie : series) {
            if (serie.isEntregado()) {
                seriesEntregadas++;
                serie.devolver();
            }
        }

        for (Videojuego videojuego : videojuegos) {
            if (videojuego.isEntregado()) {
                videojuegosEntregados++;
                videojuego.devolver();
            }
        }

        System.out.println("Series entregadas: " + seriesEntregadas);
        System.out.println("Videojuegos entregados: " + videojuegosEntregados);

        // Buscar la serie con más temporadas y el videojuego con más horas estimadas
        Serie serieMayor = series[0];
        Videojuego videojuegoMayor = videojuegos[0];

        for (Serie serie : series) {
            if (serie.compareTo(serieMayor) > 0) {
                serieMayor = serie;
            }
        }

        for (Videojuego videojuego : videojuegos) {
            if (videojuego.compareTo(videojuegoMayor) > 0) {
                videojuegoMayor = videojuego;
            }
        }

        System.out.println("Serie con más temporadas: " + serieMayor);
        System.out.println("Videojuego con más horas estimadas: " + videojuegoMayor);
    }
}
