package POO.Bloque4.VideoJuego;

// Interfaz Entregable
public interface Entregable {
    void entregar();
    void devolver();
    boolean isEntregado();
    int compareTo(Object a);
}