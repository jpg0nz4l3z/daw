package POO.Bloque4.VideoJuego;



// Clase Serie
public class Serie implements Entregable {

    // Atributos
    private String titulo, genero, creador;
    private int numeroTemporadas;
    private boolean entregado;
    // Constantes
    private static final int TEMPORADAS_POR_DEFECTO = 3;

    // Constructores
    public Serie() {
        this.titulo = "";
        this.numeroTemporadas = TEMPORADAS_POR_DEFECTO;
        this.entregado = false;
        this.genero = "";
        this.creador = "";
    }
    public Serie(String titulo, String creador) {
        this.titulo = titulo;
        this.numeroTemporadas = TEMPORADAS_POR_DEFECTO;
        this.entregado = false;
        this.genero = "";
        this.creador = creador;
    }
    public Serie(String titulo, int numeroTemporadas, String genero, String creador) {
        this.titulo = titulo;
        this.numeroTemporadas = numeroTemporadas;
        this.entregado = false;
        this.genero = genero;
        this.creador = creador;
    }

    // Métodos get y set
    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public int getNumeroTemporadas() {
        return numeroTemporadas;
    }

    public void setNumeroTemporadas(int numeroTemporadas) {
        this.numeroTemporadas = numeroTemporadas;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getCreador() {
        return creador;
    }

    public void setCreador(String creador) {
        this.creador = creador;
    }

    @Override
    public String toString() {
        return "Serie{" +
                "titulo='" + titulo + '\'' +
                ", numeroTemporadas=" + numeroTemporadas +
                ", entregado=" + entregado +
                ", genero='" + genero + '\'' +
                ", creador='" + creador + '\'' +
                '}';
    }

    // Métodos de la interfaz Entregable
    @Override
    public void entregar() {
        this.entregado = true;
    }
    @Override
    public void devolver() {
        this.entregado = false;
    }
    @Override
    public boolean isEntregado() {
        return entregado;
    }
    @Override
    public int compareTo(Object a) {
        if (a instanceof Serie) {
            Serie otra = (Serie) a;
            return Integer.compare(this.numeroTemporadas, otra.numeroTemporadas);
        }
        return 0;
    }
}
